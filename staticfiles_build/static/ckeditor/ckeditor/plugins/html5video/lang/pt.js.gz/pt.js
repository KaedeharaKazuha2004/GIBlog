CKEDITOR.plugins.setLang( 'html5video', 'pt', {
    button: 'Inserir vídeo HTML5',
    title: 'HTML5 video',
    infoLabel: 'Informações do Vídeo',
    allowed: 'Extensões permitidas: MP4, WebM, Ogv',
    urlMissing: 'O URL do vídeo está faltando.',
    videoProperties: 'Propriedades do vídeo',
    upload: 'Upload',
    btnUpload: 'Enviar para o servidor',
    advanced: 'Avançado',
    autoplay: 'Autoplay?',
    allowdownload: 'Allow download?',
    advisorytitle: 'Advisory title',
    yes: 'Sim',
    no: 'Não',
    responsive: 'Largura responsiva',
    controls: 'Exibir controles'
} );
